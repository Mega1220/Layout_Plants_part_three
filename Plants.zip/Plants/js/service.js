const gardenButton = document.querySelector(".garden__button");
const lawnButton = document.querySelector(".lawn__button");
const plantingButton = document.querySelector(".planting__button");

const gardenCards = document.querySelectorAll(".garden__card");
const lawnCards = document.querySelectorAll(".lawn__card");
const plantingCards = document.querySelectorAll(".planting__card");

gardenButton.addEventListener("click", gardenCardFilter);
lawnButton.addEventListener("click", lawnCardFilter);
plantingButton.addEventListener("click", plantingCardFilter);

function gardenCardFilter() {
    for(const gardenCard of gardenCards) {
        gardenCard.classList.remove("service__card-filter");
       
        for(const lawnCard of lawnCards) {
            lawnCard.classList.add("service__card-filter");
        }
       
        for(const plantingCard of plantingCards) {
            plantingCard.classList.add("service__card-filter");
        }
    }
}

function lawnCardFilter() {
    for(const lawnCard of lawnCards) {
        lawnCard.classList.remove("service__card-filter");
       
        for(const gardenCard of gardenCards) {
            gardenCard.classList.add("service__card-filter");
        }
       
        for(const plantingCard of plantingCards) {
            plantingCard.classList.add("service__card-filter");
        }
    }
}

function plantingCardFilter() {
    for(const plantingCard of plantingCards) {
        plantingCard.classList.remove("service__card-filter");
       
        for(const lawnCard of lawnCards) {
            lawnCard.classList.add("service__card-filter");
        }
       
        for(const gardenCard of gardenCards) {
            gardenCard.classList.add("service__card-filter");
        }
    }
}

const button = document.querySelector(".contacts__button");
const dropdown = document.querySelector(".contacts__dropdown");
const clickIcoOne = document.querySelector(".contacts__click_one");
const clickIcoTwo = document.querySelector(".contacts__click_two");

const selectItems = document.querySelectorAll(".contacts__dropdown-item");

const cityName = document.querySelector(".contacts__button-text");

const cityInformations = document.querySelectorAll(".city__information");

const mobileWidth = window.matchMedia("(max-width: 380px)")

const contactsPicture = document.querySelector(".contacts__picture")

button.addEventListener("click", open);

function open() {
    if(!button.classList.contains("contacts__button_open") || cityName.textContent === "City"){
        button.classList.toggle("contacts__button_open");
    }
    setTimeout(function() {
        clickIcoOne.classList.toggle("display__none");
        clickIcoTwo.classList.toggle("display__block");
        dropdown.classList.toggle("display__block");
    }, 10); // задержка в миллисекундах
}

for(const selectItem of selectItems) {
    selectItem.addEventListener("click", function() {
        cityName.innerHTML="";

        //текстовая нода
        const childNode = selectItem.childNodes[0];
        //клонируем текстовую ноду
        const childClone = childNode.cloneNode(true);
        //вставляем текстовую ноду в cityName
        cityName.appendChild(childClone);

        setTimeout(function() {
            clickIcoOne.classList.toggle("display__none");
            clickIcoTwo.classList.toggle("display__block");
            dropdown.classList.toggle("display__block");
        }, 10); // задержка в миллисекундах

        for(const cityInformation of cityInformations) {
            if(selectItem.id === cityInformation.id) {
                cityInformation.classList.remove("display__none");
            }
            else {
                cityInformation.classList.add("display__none");
            }
        }

        if(mobileWidth.matches) {
            contactsPicture.classList.add("display__none")
        }
    })
}
(function () {
    const burgerItem = document.querySelector('.burger');
    const menu = document.querySelector('.header__nav');
    const menuItem = document.querySelector('.header__list');

    burgerItem.addEventListener('click', () => {
        menu.classList.toggle('header__nav_active');
    });

    menuItem.addEventListener('click', () => {
        menu.classList.toggle('header__nav_active');
    });
}());
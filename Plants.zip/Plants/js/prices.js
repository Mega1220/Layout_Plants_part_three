const basicsButton = document.querySelector(".basics__button");
const standardButton = document.querySelector(".standard__button");
const proCareButton = document.querySelector(".pro-care__button");

const pricesItemsButtons = document.querySelectorAll(".prices__items-button")

const priceBasics = document.querySelector(".price__basics");
const priceStandard = document.querySelector(".price__standart");
const priceProCare = document.querySelector(".price__pro-care");

const pricesButtons = document.querySelectorAll(".prices__button")

basicsButton.addEventListener("click", basicsMenuOpen);
standardButton.addEventListener("click", standardMenuOpen);
proCareButton.addEventListener("click", proCareMenuOpen);
for(const pricesButton of pricesButtons) {
    pricesButton.addEventListener("click", pricesMenuClosed)
}

function basicsMenuOpen() {
    priceBasics.classList.remove("display__none");

    for(const pricesItemsButton of pricesItemsButtons) {
        pricesItemsButton.classList.add("display__none");
    }
}

function standardMenuOpen() {
    priceStandard.classList.remove("display__none");

    for(const pricesItemsButton of pricesItemsButtons) {
        pricesItemsButton.classList.add("display__none");
    }
}

function proCareMenuOpen() {
    priceProCare.classList.remove("display__none");

    for(const pricesItemsButton of pricesItemsButtons) {
        pricesItemsButton.classList.add("display__none");
    }
}

function pricesMenuClosed() {
    priceBasics.classList.add("display__none");
    priceStandard.classList.add("display__none");
    priceProCare.classList.add("display__none");

    for(const pricesItemsButton of pricesItemsButtons) {
        pricesItemsButton.classList.remove("display__none");
    }
}